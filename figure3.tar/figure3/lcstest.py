from numpy.random import rand,seed
from scipy.optimize import fmin
from math import *


def fml(xl,yl):
 def fl(x0):
  i=0
  lv=1.0
  mu=x0[0]
  sig=x0[1]
  while i < len(xl):
   if yl[i]==1:
    try: 
     lv*=1/(1+exp(-(xl[i]-mu)/sig))
    except:
     lv*=1 
   else:
    try:
     lv*=1/(1+exp((xl[i]-mu)/sig))
    except:
     lv*=1
   i+=1
  try:
   llv=-log(lv)
  except:
   llv=1E11
  return llv
 x0=[0,1]
 mles=fmin(fl,x0,disp=False,maxiter=100)
 return mles[0],mles[1]

#used this setup to get all but 0.8, 0.86 and 0.88 values
seed(1)
xvlist=[]
xvnow=0.7
while xvnow < 3.6:
 xvlist.append(xvnow)
 xvnow+=0.1

for xp in xvlist:
 nsimd=0
 xm=-xp
 while nsimd < 10000:
  i=0
  xt=[]
  yt=[]
  while i < 100:
   xt.append(xm)
   if 1/(1+exp(-xm)) > rand():
    yt.append(1)
   else:
    yt.append(0)
   xt.append(xp)
   if 1/(1+exp(-xp)) > rand():
    yt.append(1)
   else:
    yt.append(0)
   i+=2
  fname="logit-t"+str(xp)+"-n"+str(i)+".txt"
  fout=open(fname,"a")
  mu,sig=fml(xt,yt)
  resig=sig
  if sig < 0: resig=0.0
  if sig > 3: resig=3.0
  fout.write(str(sig)+"  "+str(resig)+"\n")
  fout.close()
  nsimd+=1
