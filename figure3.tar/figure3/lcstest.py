from numpy.random import rand,seed
from scipy.optimize import fmin
from math import *


def fml(xl,yl):
 def fl(x0):
  i=0
  lv=1.0
  mu=x0[0]
  sig=x0[1]
  while i < len(xl):
   if yl[i]==1:
    try: 
     lv*=1/(1+exp(-(xl[i]-mu)/sig))
    except:
     lv*=1 
   else:
    try:
     lv*=1/(1+exp((xl[i]-mu)/sig))
    except:
     lv*=1
   i+=1
  try:
   llv=-log(lv)
  except:
   llv=1E11
  return llv
 x0=[0,1]
 mles=fmin(fl,x0,disp=False,maxiter=100)
 return mles[0],mles[1]

def fishlog(xl,yl,mu,sig):
 a1=0
 i=0
 while i < len(xl):
  try: 
   a1+=(xl[i]-mu)/sig/(1+exp(-(xl[i]-mu)/sig))/(1+exp((xl[i]-mu)/sig))
  except:
   a1+=0
  i+=1
 return a1

"""
#used this setup to get all but 0.8, 0.86 and 0.88 values
seed(1)
nsimd=0
xvlist=[]
xvnow=0.8
while xvnow < 3.6:
 xvlist.append(xvnow)
 xvnow+=0.1
xvnow=0.82
while xvnow < 3.6:
 xvlist.append(xvnow)
 xvnow+=0.1
xvnow=0.84
while xvnow < 3.6:
 xvlist.append(xvnow)
 xvnow+=0.1
xvnow=0.86
while xvnow < 3.6:
 xvlist.append(xvnow)
 xvnow+=0.1
xvnow=0.88
while xvnow < 3.6:
 xvlist.append(xvnow)
 xvnow+=0.1
"""
seed(2)
xnow=0.6
xvlist=[]
while xnow < 0.9:
 xvlist.append(xnow)
 xnow+=0.02
xnow=0.605
while xnow < 0.9:
 xvlist.append(xnow)
 xnow+=0.02
xnow=0.61
while xnow < 0.9:
 xvlist.append(xnow)
 xnow+=0.02
xnow=0.615
while xnow < 0.9:
 xvlist.append(xnow)
 xnow+=0.02

for xp in xvlist:
 #xp=1.4
 nsimd=0
 xm=-xp
 while nsimd < 10000:
  i=0
  xt=[]
  yt=[]
  while i < 100:
   xt.append(xm)
   if 1/(1+exp(-xm)) > rand():
    yt.append(1)
   else:
    yt.append(0)
   xt.append(xp)
   if 1/(1+exp(-xp)) > rand():
    yt.append(1)
   else:
    yt.append(0)
   i+=2
  fname="logit-t"+str(xp)+"-n"+str(i)+".txt"
  fout=open(fname,"a")
  mu,sig=fml(xt,yt)
  #if sig < 10:
  # fout.write(str(sig)+"\n")
  #if sig > xp-xm: sig=xp-xm
  resig=sig
  if sig < 0: resig=0.0
  if sig > 3: resig=3.0
  fout.write(str(sig)+"  "+str(resig)+"\n")
  fout.close()
  nsimd+=1
