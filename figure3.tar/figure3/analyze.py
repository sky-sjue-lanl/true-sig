from math import *
import sys

print("#"+sys.argv[1])
afile=open(sys.argv[1],"r")
lines=afile.readlines()
afile.close()

print("#tval  sigma1   dsigma1   sigma2   dsigma2")

for aline in lines:
 rsigs1=[]
 rsigs2=[]
 aline=aline.strip()
 afile=open(aline,"r")
 siglines=afile.readlines()
 afile.close()
 for asl in siglines:
  vals=asl.split()
  rsigs1.append(float(vals[0]))
  rsigs2.append(float(vals[1]))
 sigav1=0.0
 sigav2=0.0 
 for asig in rsigs1:
  sigav1+=asig
 for asig in rsigs2:
  sigav2+=asig
 sigav1/=(1.0*len(rsigs1))
 sigav2/=(1.0*len(rsigs2))
 varsigav1=0.0
 varsigav2=0.0
 for asig in rsigs1:
  varsigav1+=(asig-sigav1)**2
 for asig in rsigs2:
  varsigav2+=(asig-sigav2)**2
 ssig1=sqrt(varsigav1/(1.0*len(rsigs1)-1.0))
 ssig2=sqrt(varsigav2/(1.0*len(rsigs2)-1.0))
 il=aline.find("-t")
 ir=aline.rfind("-n")
 itval=int(100.0*float(aline[il+2:ir]))
 tval=0.01*itval
 print(str(tval)+"  "+str(sigav1)+"  "+str(ssig1)+"  "+str(sigav2)+"  "+str(ssig2))

