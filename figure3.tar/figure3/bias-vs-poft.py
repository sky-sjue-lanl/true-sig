#!/usr/bin/python

from math import *

def pl(x):
 return 1.0/(1.0+exp(-x))

def ql(x):
 return 1.0/(1.0+exp(x))

def wl(x):
 return pl(x)*ql(x)

def pg(x):
 return 0.5+0.5*erf(x/sqrt(2.0))

def qg(x):
 return 0.5-0.5*erf(x/sqrt(2.0))

def bl(x):
 return ((1.0-2.0*pl(x))/x+1.0/x**2)/wl(x)

def bg(x):
 return 2.0*pi*pg(x)*qg(x)*exp(x**2)*(1.0/x**2-1.0)

tvals=[]
tnow=0.3
while tnow <= 4.0:
 tvals.append(tnow)
 tnow+=0.005

fout=open("bg-of-t.txt","w")
for t in tvals:
 bnow=bg(t) 
 fout.write(str(t)+"  "+str(bnow)+"\n")
fout.close()

fout=open("bl-of-t.txt","w")
for t in tvals:
 bnow=bl(t) 
 fout.write(str(t)+"  "+str(bnow)+"\n")
fout.close()

fout=open("bg-of-p.txt","w")
for t in tvals:
 pnow=pg(t)
 bnow=bg(t) 
 fout.write(str(pnow)+"  "+str(bnow)+"\n")
fout.close()

fout=open("bl-of-p.txt","w")
for t in tvals:
 pnow=pl(t)
 bnow=bl(t) 
 fout.write(str(pnow)+"  "+str(bnow)+"\n")
fout.close()

