from numpy.random import rand,seed
from scipy.optimize import fmin
from math import *


def fml(xl,yl):
 def fl(x0):
  i=0
  lv=1.0
  mu=x0[0]
  sig=x0[1]
  while i < len(xl):
   try:
    argnow=(xl[i]-mu)/sig
   except:
    if xl[i] > mu:
     argnow=100.0
    elif xl[i] == mu:
     argnow=0.0
    else:
     argnow=-100.0
   if yl[i]==1:
    try: 
     #lv*=1/(1+exp(-(xl[i]-mu)/sig))
     lv*=(0.5+0.5*erf(argnow/sqrt(2.0)))
    except:
     lv*=1 
   else:
    try:
     #lv*=1/(1+exp((xl[i]-mu)/sig))
     lv*=(0.5-0.5*erf(argnow/sqrt(2.0)))
    except:
     lv*=1
   i+=1
  try:
   llv=-log(lv)
  except:
   llv=1E11
  return llv
 x0=[0,1]
 mles=fmin(fl,x0,disp=False,maxiter=100)
 return mles[0],mles[1]

seed(1)
xvlist=[]
xvnow=0.5
while xvnow < 3.6:
 xvlist.append(xvnow)
 xvnow+=0.1
 
for xp in xvlist:
 nsimd=0
 xm=-xp
 while nsimd < 10000:
  i=0
  xt=[]
  yt=[]
  while i < 100:
   xt.append(xm)
   #if 1/(1+exp(-xm)) > rand():
   if 0.5+0.5*erf(xm/sqrt(2.0)) > rand():
    yt.append(1)
   else:
    yt.append(0)
   xt.append(xp)
   if 0.5+0.5*erf(xp/sqrt(2.0)) > rand():
   #if 1/(1+exp(-xp)) > rand():
    yt.append(1)
   else:
    yt.append(0)
   i+=2
  fname="probit-t"+str(xp)+"-n"+str(i)+".txt"
  fout=open(fname,"a")
  mu,sig=fml(xt,yt)
  resig=sig
  if sig < 0: resig=0.0
  if sig > 3: resig=3.0
  fout.write(str(xp)+"  "+str(sig)+"  "+str(resig)+"\n")
  fout.close()
  nsimd+=1
